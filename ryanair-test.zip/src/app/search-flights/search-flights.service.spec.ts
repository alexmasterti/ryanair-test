import { TestBed, inject } from '@angular/core/testing';

import { SearchFlightsService } from './search-flights.service';

describe('SearchFlightsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SearchFlightsService]
    });
  });

  it('should be created', inject([SearchFlightsService], (service: SearchFlightsService) => {
    expect(service).toBeTruthy();
  }));
});
